v={"adxl345":3,"files":3, "icons":2, "main":4, "prefs":3,  "sensors":3, "servo":2, "ssd1306":2, "standalone":1, "webconnect":1}
