mode='blemode'
